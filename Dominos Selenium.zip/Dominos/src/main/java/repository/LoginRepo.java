package repository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginRepo
{
	static WebElement element;

	public static WebElement login(WebDriver driver)
	{
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30));
		element= driver.findElement(By.xpath("//div[contains(text(),'Login | Signup')]"));
		wait.until(ExpectedConditions.elementToBeClickable(element));
		return element;
	}
	public static WebElement mobNo(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		element= driver.findElement(By.name("loginNumber"));
		return element;
	}

	public static WebElement submit(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[value='SUBMIT']"));
		return element;
	}	
	public static WebElement otp(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		element= driver.findElement(By.cssSelector("input[maxlength='6']"));
		//
		//WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30));//
		//WebElement element= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body/div[@id='__next']/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]")));
		//element= driver.findElement(By.xpath("//body/div[@id='__next']/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]"));
		return element;
	}
	public static WebElement okbutton(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//div/button/span[contains(text(), 'Ok')]"));
		return element;
	}
	public static WebElement esc(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/span"));
		return element; 
	}
	public static WebElement otpsubmit(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//div/button/span[contains(text(), 'SUBMIT')]"));
		return element;
	}
	public static WebElement logout1(WebDriver driver)
	{
		element= driver.findElement(By.className("hdr-lgn-txt-hd"));
		return element;
	}
	public static WebElement logout(WebDriver driver)
	{
		element= driver.findElement(By.className("btn--grn"));
		return element;
	}
}
