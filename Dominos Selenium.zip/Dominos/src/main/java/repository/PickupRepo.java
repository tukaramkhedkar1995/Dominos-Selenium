package repository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PickupRepo 
{
	static WebElement element;
	public static WebElement Pickup(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("label[data-label='Order_Type_Pickup']"));
		return element;
	}
	public static WebElement City(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[placeholder='Select City']"));
		//element= driver.findElement(By.xpath("//body/div[@id='__next']/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/img[2]"));
		return element;
	}
	public static WebElement Arrow(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[1]/div/div/div/img[2]"));
		return element;
	}
	public static WebElement Name(WebDriver driver)
	{
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30));
		element= driver.findElement(By.cssSelector("li[data-label='location_FARIDABAD']"));
		//element= driver.findElement(By.xpath("//span[contains(text(),'BANKURA')]"));
		wait.until(ExpectedConditions.elementToBeClickable(element));
		return element;
	}
	public static WebElement Store(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[data-label='Select Store']"));
		return element;
	}
	public static WebElement Storenm(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[2]/div/ul/li[2]/div[2]/span"));
		return element;
	}

	
}
