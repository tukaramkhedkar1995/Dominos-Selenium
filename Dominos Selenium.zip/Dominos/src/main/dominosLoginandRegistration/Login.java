package dominosLoginandRegistration;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;

public class Login 
{
	WebDriver driver;
  @Test
  public void f()
  {
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	  File fs= new File("Data\\Mobnum.xlsx");
	  FilleInputStream fis= new FileInputStream(fs);
	  XSSFWorkbook wb=new XSSFWorkbook(fis);
	  XSFSheet sh1=wb.getSheet("Sheet1");
	  for(int i=0; i<3; i++)
	  {
		 String mobno=sh1.getRow(i).getCell(0).toString();
		 Repository.Signup.login(driver).click();
		 
	  }
  }
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  WebDriver driver =new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://pizzaonline.dominos.co.in");
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
