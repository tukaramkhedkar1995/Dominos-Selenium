package Dominos.D;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileRead 
{
	public static void readf(String fname, String shname) throws IOException 
	{
		File f=new File("Data/"+fname);
		FileInputStream fis= new FileInputStream(f);
		System.out.println("File Opened Sucessfully");
		XSSFWorkbook wk= new XSSFWorkbook(fis);
		
		XSSFSheet sh1= wk.getSheet(shname);
		XSSFSheet sh3= wk.getSheet(shname);
	}

}
