package repository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EveryDayRepo 
{
	static WebElement element;
	
	public static WebElement Day(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//span[contains(text(),'EVERYDAY VALUE')]"));
		return element;
	}
	public static WebElement Order(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//body/div[@id='__next']/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[11]/div[1]/div[1]/button[1]"));
		//element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[11]/div[1]/div[1]/button[1]/span[1]"));
		return element;
	}
	public static WebElement Arrow(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
		//element= driver.findElement(By.xpath("//body/div[@id='__next']/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
		return element;
	}
	public static WebElement Crust(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[2]/span[1]/span[1]/b[1]"));
		return element;
	}
	public static WebElement Select(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/button[1]/span[1]"));
		return element;
	}
	public static WebElement Addition1(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("div[data-label='increase']"));
		return element;
	}
	public static WebElement AddtoCard(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[2]/div[3]/div[1]/div[1]/div[4]/div[2]/button[1]/span[1]"));
		return element;
	}
	public static WebElement Checkout(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='miniCartCheckout']"));
		return element;
	}
	public static WebElement Placeorder(WebDriver driver)
	{
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[6]/div/div/div[7]/button"));
		element= driver.findElement(By.cssSelector("button[data-label='Place Order']"));
		return element;
	}
	public static WebElement Pick(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("label[data-label='Order_Type_Pickup']"));
		return element;
	}
	public static WebElement City(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[placeholder='Select City']"));
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[1]/div/div/div/img[2]"));
		return element;
	}
	public static WebElement City1(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[1]/div/div/div/img[2]"));
		return element;
	}
	public static WebElement SelectCity(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[1]/div/ul/li[208]/div[2]/span"));
		return element;
	}
	public static WebElement Store(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[placeholder='Select Store']"));
		return element;
	}
	public static WebElement Store2(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[2]/div/div/div/img[2]"));
		return element;
	}
	public static WebElement Storenm(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[2]/div/ul/li/div[2]/span"));
		return element;
	}
	public static WebElement Ok(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[2]/div/div[3]/div/button"));
		return element;
	}
	public static WebElement Pro(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[3]/div[2]/button"));
		return element;
	}
	public static WebElement Add(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[1]/div/div/div[2]/div[2]/div/div/div[2]/ul/li[5]/div/div[2]/div"));
		return element;
	}
	public static WebElement Placeorder1(WebDriver driver)
	{
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[6]/div/div/div[7]/button"));
		element= driver.findElement(By.cssSelector("button[data-label='Place Order']"));
		return element;
	}
	
	
	
	
	/*
	public static WebElement Area(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[placeholder='Enter Area / Locality']"));
		return element;
	}
	/*public static WebElement City(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("li[data-label='location_[object Object']"));
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[2]/div/ul/li[1]/div[2]/span[1]"));
		return element;
	}*/
	
	
	
	
	/*
	public static WebElement LoacteMe(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='Locate_Me']"));
		return element;
	}
	public static WebElement SelectLoc(WebDriver driver)
	{
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(30));
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[3]/div/div[2]/div[2]/button"));
		element= driver.findElement(By.cssSelector("button[class='btn--blue]"));
		wait.until(ExpectedConditions.elementToBeClickable(element));
		return element;
	}
	/*
	
	
	
	
	
	/*public static WebElement FirstNm(WebDriver driver)
	{
		element= driver.findElement(By.name("firstName"));
		return element;
	}
	public static WebElement LastNm(WebDriver driver)
	{
		element= driver.findElement(By.name("lastName"));
		return element;
	}
	public static WebElement MobileNo(WebDriver driver)
	{
		element= driver.findElement(By.name("mobileNumber"));
		return element;
	}
	public static WebElement Email(WebDriver driver)
	{
		element= driver.findElement(By.name("emailBox"));
		return element;
	}*/
}
