package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CouponRp
{
	static WebElement element;
	public static WebElement Paneer(WebDriver driver)
	{
		//element= driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div/div[4]/div/div/div[2]/div[3]/div/button"));
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[8]/div/div[11]/div/div/div[2]/div[3]/div/button"));
		//element= driver.findElement(By.cssSelector("button[data-label='addTocart']"));
		return element;
	}
	public static WebElement Adv(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/div[8]/div/div[1]/div/div/div[2]/div[3]/div[1]/button/span"));
		//element= driver.findElement(By.cssSelector("button[data-label='miniCartCheckout']"));
		return element;
	}
	/*public static WebElement AdvClose(WebDriver driver)
	{
		element= (WebElement) driver.switchTo().frame(driver.findElement(By.id("moengage-web-helper-frame")));
		return element;
	}*/
	public static WebElement Check(WebDriver driver)
	{
		//element= driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/button[1]/span[1]"));
		element= driver.findElement(By.cssSelector("button[data-label='miniCartCheckout']"));
		return element;
	}
	/*public static WebElement Offer(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[2]/div[1]/div[5]/div[2]/span[1]"));
		return element;
	}
	public static WebElement Code(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/input[1]"));
		//element= driver.findElement(By.cssSelector("input[data-label='Enter coupon code here,]"));
		return element;
	}
	public static WebElement Apply(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[1]/div/div[3]/div/div[2]/div[1]/div[2]/button"));
		return element;
	}
	/*public static WebElement Strips(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[1]"));
		return element;
	}*/
	public static WebElement Placeholder(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='Place Order']"));
		return element;
	}
	public static WebElement Area(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[placeholder='Enter Area / Locality']"));
		return element;
	}
	public static WebElement Locateme(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[1]/div[2]/button"));
		return element;
	}
	/*public static WebElement Loc(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div/div[1]/div[2]/div[2]/div/ul/li[1]/div[2]"));
		return element;
	}*/
	public static WebElement Placeholder1(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='Place Order']"));
		return element;
	}
	public static WebElement FirstNm(WebDriver driver)
	{
		element= driver.findElement(By.name("firstName"));
		return element;
	}
	public static WebElement LastNm(WebDriver driver)
	{
		element= driver.findElement(By.name("lastName"));
		return element;
	}
	public static WebElement MobileNo(WebDriver driver)
	{
		element= driver.findElement(By.name("mobileNumber"));
		return element;
	}
	public static WebElement Email(WebDriver driver)
	{
		element= driver.findElement(By.name("emailBox"));
		return element;
	}
	public static WebElement Address(WebDriver driver)
	{
		element= driver.findElement(By.name("addressBox"));
		return element;
	}
	public static WebElement HouseNo(WebDriver driver)
	{
		element= driver.findElement(By.name("houseNumber"));
		return element;
	}
	public static WebElement Save(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/div[3]/div/div[3]/div/div/div[4]/div/div/input"));
		return element;
	}
	public static WebElement UPI(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/div/div[1]/div[5]/span"));
		return element;
	}

}
