package dominosLoginandRegistration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;

public class Login {

	public static void main(String[] args) throws IOException 
	{
		/*WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();*/
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver= new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://pizzaonline.dominos.co.in");
		
		File fs= new File("Data\\Mobnum.xlsx");
		FileInputStream fis= new FileInputStream(fs); 
		
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sh1= wb.getSheet("Sheet1");
		Actions act=new Actions(driver);
		for(int i=1; i<=4; i++)
		{
			String mobno=sh1.getRow(i).getCell(0).toString();
			System.out.println(mobno);
			LoginRepo.login(driver).click();
			try
			{
				LoginRepo.mobNo(driver).sendKeys(mobno);
				//act.moveToElement(LoginRepo.submit(driver)).click().build().perform();
				//LoginRepo.submit(driver).click();
				Thread.sleep(3000);
				JavascriptExecutor js= (JavascriptExecutor)driver;
				
				js.executeScript("arguments[0].click();",LoginRepo.submit(driver) );
				System.out.println("Clicked on Submit");
			    try
			    {
			    	LoginRepo.okbutton(driver).click();
			    }
			    catch(Exception e)
			    {
			    	LoginRepo.otp(driver).sendKeys("123456");
					
					js.executeScript("arguments[0].click();", LoginRepo.otpsubmit(driver));
			    }
				
				Thread.sleep(3000);
				
				LoginRepo.esc(driver).click();
				try
				{
					LoginRepo.logout1(driver).click();
					LoginRepo.logout(driver).click();
				}
				catch(Exception e)
				{
					
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
				System.out.println("Invalid mobile number");
				System.out.println();
			}
		}
		
		driver.close();
	}
}

