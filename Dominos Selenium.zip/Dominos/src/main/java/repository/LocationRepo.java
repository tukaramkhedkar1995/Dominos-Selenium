package repository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LocationRepo 
{
	static WebElement element;
	
	public static WebElement Address(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/div[2]/div[1]/div/div[3]/input"));
		//element= driver.findElement(By.cssSelector("input[placeholder='Enter your delivery address']"));
		return element;
	}
	public static WebElement Locateme(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/div[2]/div[1]/div/div[3]/div/button/span"));
		//element= driver.findElement(By.cssSelector("button[data-label='Locate_Me']"));
		return element;
	}
	public static WebElement Addtocard(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/button[1]"));
		//element= driver.findElement(By.cssSelector("button[data-label='addTocart']"));
	    return element;
	}
	public static WebElement Addition1(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("div[data-label='increase']"));
		return element;
	}
	public static WebElement Checkout(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='miniCartCheckout']"));
		return element;
	}
	public static WebElement Placeorder(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("button[data-label='Place Order']"));
		return element;
	}
	public static WebElement FirstNm(WebDriver driver)
	{
		element= driver.findElement(By.name("firstName"));
		return element;
	}
	public static WebElement LastNm(WebDriver driver)
	{
		element= driver.findElement(By.name("lastName"));
		return element;
	}
	public static WebElement MobileNo(WebDriver driver)
	{
		element= driver.findElement(By.name("mobileNumber"));
		return element;
	}
	public static WebElement Email(WebDriver driver)
	{
		element= driver.findElement(By.name("emailBox"));
		return element;
	}
	public static WebElement Add(WebDriver driver)
	{
		element= driver.findElement(By.name("addressBox"));
		return element;
	}
	public static WebElement HouseNo(WebDriver driver)
	{
		element= driver.findElement(By.name("houseNumber"));
		return element;
	}
	public static WebElement Save(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[2]/div[1]/div[3]/div[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/input[1]"));
		return element;
	}
	public static WebElement Card(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/div/div[1]/div[2]"));
		return element; 
	}
	public static WebElement CardNo(WebDriver driver)
	{
		element= driver.findElement(By.name("cardNumber"));
		return element;
	}
	public static WebElement MonthArrow(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/div/div[2]/div/div[2]/div[2]/div/div[1]/div"));
		return element;
	}
	public static WebElement MonthNo(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/ul[1]/li[5]/div[1]/span[1]"));
		return element;
	}
	public static WebElement YearArrow(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]"));
		return element;
	}
	public static WebElement YearNo(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/ul[1]/li[4]/div[1]/span[1]"));
		return element;
	}
	public static WebElement NameOnCard(WebDriver driver)
	{
		element= driver.findElement(By.name("nameOnCard"));
		return element;
	}
	public static WebElement CvvNo(WebDriver driver)
	{
		element= driver.findElement(By.name("loginNumber"));
		return element;
	}
	public static WebElement PayNow(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/button[1]/span[1]"));
		return element;
	}
}
